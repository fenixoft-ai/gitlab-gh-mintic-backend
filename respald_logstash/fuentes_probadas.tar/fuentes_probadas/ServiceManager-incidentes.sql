SELECT category,opened_by,clr_txt_company_code,contact_name,clr_bmcdatevent,
clr_txt_idbneficmtc,severity,clr_bmc_location,clr_bmc_host,open_time,
resolved_time,assignment,subcategory, product_type, resolution, "NUMBER" FROM USRODI.SM_INCIDENTES 
where contact_name= 'bmcintegrationsm' and open_time >:sql_last_value order by open_time
