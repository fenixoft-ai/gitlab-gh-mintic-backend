SELECT resolution_code, variable2, category, contact_fullname, variable3, open_time, product_type, incident_id,
variable1, severity, initial_impact, current_phase, owner_name, clr_txt_idbneficmtc, clr_txt_tiposervicio, gl_number,
clr_txt_codcategorymtc, company_id, source, close_time, resolution, open, clr_txt_assignment, variable4 
FROM USRODI.SM_INTERACCIONES 
WHERE clr_txt_assignment='EYN - NOCMINTIC' and open_time >:sql_last_value  order by open_time
