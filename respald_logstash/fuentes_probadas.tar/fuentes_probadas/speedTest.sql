SELECT getdate() as ppp, LO.Locationid, LO.Institution_id, INV.apid, LO.beneficiary_code,
 RE.result_upload_mbps, RE.result_start_date, RE.result_end_date, RE.result_download_mbps
 FROM Locations as LO
 INNER JOIN APInventory as INV ON LO.locationid = INV.location_id
 INNER JOIN STResults as RE ON INV.apid = RE.ap_id
WHERE RE.result_start_date >:sql_last_value
ORDER BY  RE.result_start_date
