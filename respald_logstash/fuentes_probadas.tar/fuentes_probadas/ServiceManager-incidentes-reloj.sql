SELECT 'Monitoreo' AS callback_type, INC.category, INC.close_time, INC.clr_txt_idbneficmtc, INC.contact_name, INC.initial_impact, INC.open_time, INC.opened_by, 
INC.resolution_code, INC.resolved_time,INC.subcategory,INC.variable1,INC.variable2,INC.variable3,'Incidencia' AS Variable4,INC.assignment, INC.severity,REL.key_char,
REL.name,REL.total,REL.close_date 
FROM  USRODI.SM_INCIDENTES_MINTIC INC 
RIGHT JOIN USRODI.SM_RELOJES REL ON REL.KEY_CHAR = INC.INCIDENT_ID 
where INC.assignment = 'EYN - NOCMINTIC' AND inc.open_time > :sql_last_value  order by inc.open_time
