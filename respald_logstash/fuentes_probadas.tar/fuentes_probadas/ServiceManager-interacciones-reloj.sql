SELECT inte.callback_type, inte.category, inte.close_time, inte.clr_txt_idbneficmtc, inte.contact_name, inte.initial_impact, inte.open_time, inte.opened_by, 
inte.resolution_code, inte.resolved_time, inte.subcategory, inte.variable1, inte.variable2, inte.variable3, inte.variable4, inte.clr_txt_assignment, inte.severity, 
REL.key_char, REL.name, REL.total, REL.close_date 
FROM USRODI.SM_INTERACCIONES INTE 
RIGHT JOIN USRODI.SM_RELOJES REL ON REL.KEY_CHAR = INTE.INCIDENT_ID 
where INTE.clr_txt_assignment = 'EYN - NOCMINTIC' and INTE.opened_by= 'smservicedeskplus' and inte.open_time > :sql_last_value order by inte.open_time 
